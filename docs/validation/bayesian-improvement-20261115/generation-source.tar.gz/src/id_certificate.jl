"""Run provenance metadata bridging CausalDynamics identification."""

using DataFrames
using Dates
using CausalDynamics

"""
    IdentificationCertificate

Application-layer certificate wrapping `CausalDynamics.IdentificationResult` with column symbols.
"""
struct IdentificationCertificate
    trt::Symbol
    outcome::Symbol
    result::IdentificationResult
    adjustment::Vector{Symbol}
    mediators::Vector{Symbol}
    nuisance_source::Symbol
    temporal_lags::Union{Nothing, NamedTuple}
    provenance::Union{Nothing, CausalDynamics.CDMProvenance}
end

"""
    IdentificationCertificate(trt, outcome, result, adjustment, mediators,
        nuisance_source, temporal_lags)

Backward-compatible positional constructor for certificates created before CDM
provenance was added. New code should use [`identification_certificate`](@ref).
"""
function IdentificationCertificate(
    trt::Symbol,
    outcome::Symbol,
    result::IdentificationResult,
    adjustment::Vector{Symbol},
    mediators::Vector{Symbol},
    nuisance_source::Symbol,
    temporal_lags::Union{Nothing, NamedTuple},
)
    return IdentificationCertificate(
        trt, outcome, result, adjustment, mediators, nuisance_source, temporal_lags, nothing,
    )
end

"""
    identification_certificate(result, trt, outcome; adjustment, mediators, nuisance_source, temporal_lags, provenance) -> IdentificationCertificate

Wrap a CausalDynamics `IdentificationResult` in `IdentificationCertificate` for MTP planning.
`adjustment` and `mediators` default to `Symbol.(result.adjustment)` and `Symbol.(result.mediators)`; `nuisance_source`
tags where nuisances were planned from (`:graph`, temporal, etc.). Optional `provenance` carries CDM lineage when the
result came from a dynamics certificate.
"""
function identification_certificate(
    result::IdentificationResult,
    trt::Symbol,
    outcome::Symbol;
    adjustment::Vector{Symbol} = Symbol.(result.adjustment),
    mediators::Vector{Symbol} = Symbol.(result.mediators),
    nuisance_source::Symbol = :graph,
    temporal_lags::Union{Nothing, NamedTuple} = nothing,
    provenance::Union{Nothing, CausalDynamics.CDMProvenance} = nothing,
)
    return IdentificationCertificate(
        trt, outcome, result,
        adjustment, mediators,
        nuisance_source, temporal_lags, provenance,
    )
end

"""
    certificate_dict(cert::IdentificationCertificate) -> Dict{String, Any}

Flatten `IdentificationCertificate` into string-keyed metadata for CSV join / provenance columns: merges
`CausalDynamics.certificate_dict(result)` with id-specific keys (`id_trt`, `id_adjustment`, …) and, when present,
`cdm_*` entries from `CausalDynamics.provenance_dict(provenance)`.
"""
function certificate_dict(cert::IdentificationCertificate)
    r = cert.result
    base = CausalDynamics.certificate_dict(r)
    metadata = Dict{String, Any}(
        "certificate_schema_version" => CausalDynamics.certificate_schema_version(),
        "id_trt" => string(cert.trt),
        "id_outcome" => string(cert.outcome),
        "id_adjustment" => join(string.(cert.adjustment), ","),
        "id_mediators" => join(string.(cert.mediators), ","),
        "id_identifiable" => r.identifiable,
        "id_strategy" => string(r.strategy),
        "id_graph_hash" => string(r.graph_hash, base = 16),
        "id_semantic_fingerprint" => r.semantic_fingerprint === nothing ? missing :
            string(r.semantic_fingerprint, base = 16),
        "id_identification_status" => string(r.identification_status),
        "id_nuisance_source" => string(cert.nuisance_source),
        "id_temporal" => cert.temporal_lags !== nothing,
        "id_temporal_treat_lag" => cert.temporal_lags === nothing ? missing : cert.temporal_lags.treat_lag,
        "id_temporal_outcome_lag" => cert.temporal_lags === nothing ? missing : cert.temporal_lags.outcome_lag,
        "id_assumptions" => join(string.(r.assumptions), ","),
    )
    if cert.provenance !== nothing
        for (key, value) in CausalDynamics.provenance_dict(cert.provenance)
            metadata["cdm_$(key)"] = value
        end
        metadata["cdm_fingerprint"] = CausalDynamics.provenance_fingerprint(cert.provenance)
    end
    return metadata
end

"""
    RunMetadata

Provenance for a single MTP grid execution.
"""
struct RunMetadata
    estimand_type::String
    engine::Symbol
    estimator::String
    density_ratio::String
    learners_outcome::String
    learners_trt::String
    n_mc::Int
    folds::Int
    epochs::Int
    parallel::Bool
    cache_nuisances::Bool
    package_version::String
    run_utc::String
    certificate::IdentificationCertificate
end

"""Read the `version` line from this package's `Project.toml`, or return `0.1.0` if missing."""
function pkg_version_string()
    path = joinpath(pkgdir(@__MODULE__), "Project.toml")
    isfile(path) || return "0.1.0"
    for line in eachline(path)
        m = match(r"^version\s*=\s*\"([^\"]+)\"", line)
        m !== nothing && return m.captures[1]
    end
    return "0.1.0"
end

"""
    build_run_metadata(estimand, cert; estimator, density_ratio, learners_outcome, learners_trt, n_mc, folds, epochs, parallel, cache_nuisances) -> RunMetadata

Capture one row of execution context: estimand string and `estimand_engine`, learner stacks (comma-joined strings),
MTP settings, UTC timestamp, and embedded `cert`. Used by `metadata_dict` / `attach_run_metadata!`.
"""
function build_run_metadata(
    estimand::Estimand,
    cert::IdentificationCertificate;
    estimator::Symbol = :tmle,
    density_ratio::Symbol = :gaussian,
    learners_outcome = DEFAULT_SL_LEARNERS,
    learners_trt = DEFAULT_SL_LEARNERS,
    n_mc::Int = 32,
    folds::Int = mtp_settings().folds,
    epochs::Int = 1,
    parallel::Bool = false,
    cache_nuisances::Bool = false,
)
    return RunMetadata(
        string(typeof(estimand)),
        estimand_engine(estimand),
        string(estimator),
        string(density_ratio),
        join(string.(collect(learners_outcome)), ","),
        join(string.(collect(learners_trt)), ","),
        n_mc,
        folds, epochs, parallel, cache_nuisances,
        pkg_version_string(),
        string(Dates.now(UTC)),
        cert,
    )
end

"""
    metadata_dict(meta::RunMetadata) -> Dict{String, Any}

Merge `certificate_dict` on `meta.certificate` with `meta_*` run keys (engine, folds, epochs, parallel, package version, etc.).
"""
function metadata_dict(meta::RunMetadata)
    d = certificate_dict(meta.certificate)
    merge!(d, Dict{String, Any}(
        "meta_estimand_type" => meta.estimand_type,
        "meta_engine" => string(meta.engine),
        "meta_estimator" => meta.estimator,
        "meta_density_ratio" => meta.density_ratio,
        "meta_learners" => meta.learners_outcome,
        "meta_learners_trt" => meta.learners_trt,
        "meta_n_mc" => meta.n_mc,
        "meta_folds" => meta.folds,
        "meta_epochs" => meta.epochs,
        "meta_parallel" => meta.parallel,
        "meta_cache" => meta.cache_nuisances,
        "meta_package_version" => meta.package_version,
        "meta_run_utc" => meta.run_utc,
    ))
    return d
end

"""
    attach_run_metadata!(df, meta::RunMetadata) -> DataFrame

Add one column per entry of `metadata_dict` to `df`, each filled with the scalar value on every row (wide provenance block).
"""
function attach_run_metadata!(df::DataFrame, meta::RunMetadata)
    cols = metadata_dict(meta)
    for (k, v) in cols
        df[!, k] = fill(v, nrow(df))
    end
    return df
end

export IdentificationCertificate, RunMetadata
export identification_certificate, certificate_dict
export build_run_metadata, metadata_dict, attach_run_metadata!
