"""Missing data handling: IPCW for outcome missingness and mean-imputation for covariates.

Follows the tlverse convention: model P(observed | W) via SuperLearner, then
reweight estimating equations by stabilised inverse-probability-of-censoring weights.
Covariate missingness is handled by column-wise mean/mode imputation with added
missingness indicator columns.

Missingness is treated as stratum × PCH rung: Structural claims about response
indicators `R` belong in CausalDynamics; this module owns Observable numerical
policies for a chosen estimand. Survival censoring IPCW is a separate Dynamical
object from MAR missing terminal outcomes.

# References

- van der Laan & Rose (2011) — IPCW-TMLE
- Weberpals et al. (2024) — bias–coverage trade-offs for missing-data methods in TMLE
"""

using DataFrames
using Statistics
using Random
using StableRNGs

"""
    MissingDataResult

Result of [`handle_missing_data`](@ref): cleaned table, row weights, extra
indicator columns, and metadata (`strategy`, miss rates, optional PCH `rung`).

Destructuring `data, weights, extra = result` remains supported.
"""
struct MissingDataResult
    data::DataFrame
    weights::Vector{Float64}
    extra_cols::Vector{Symbol}
    meta::NamedTuple
end

function Base.iterate(r::MissingDataResult, state::Int = 1)
    state == 1 && return (r.data, 2)
    state == 2 && return (r.weights, 3)
    state == 3 && return (r.extra_cols, 4)
    return nothing
end

Base.length(::MissingDataResult) = 3

"""
    complete_numeric_column(col; name=:column) -> Vector{Float64}

Convert a complete column to `Float64`. Throws if any entry is `missing`
(refuses silent coercion; call [`handle_missing_data`](@ref) first).
"""
function complete_numeric_column(col; name::Symbol = :column)
    any(ismissing, col) && throw(ArgumentError(
        "column :$name contains missing values; call handle_missing_data " *
        "(or another documented Observable policy) before Float64 coercion",
    ))
    return Float64[Float64(v) for v in col]
end

"""
    impute_covariates_mean!(df, cols) -> Vector{Symbol}

Replace `missing` values in each column of `cols` with the column mean (continuous)
or mode (categorical). Adds binary indicator columns `col_miss` for each imputed
column. Returns the names of the added indicator columns.

Modifies `df` in place.
"""
function impute_covariates_mean!(df::DataFrame, cols::Vector{Symbol})
    indicators = Symbol[]
    for c in cols
        col = df[!, c]
        miss_mask = ismissing.(col)
        any(miss_mask) || continue

        ind_name = Symbol(string(c) * "_miss")
        df[!, ind_name] = Float64.(miss_mask)
        push!(indicators, ind_name)

        non_miss = skipmissing(col)
        if eltype(non_miss) <: Number
            fill_val = mean(non_miss)
            df[!, c] = coalesce.(col, fill_val)
        else
            # Mode for non-numeric
            counts = Dict{Any,Int}()
            for v in non_miss
                counts[v] = get(counts, v, 0) + 1
            end
            isempty(counts) && throw(ArgumentError(
                "cannot impute covariate :$c because it has no observed values",
            ))
            fill_val = first(sort(collect(counts), by = x -> -x[2]))[1]
            df[!, c] = coalesce.(col, fill_val)
        end
    end
    return indicators
end

"""
    ipcw_weights(df, outcome, covariates; learners, folds, rng) -> Vector{Float64}

Fit P(R=1 | W) where R = !ismissing(outcome), and return stabilised
inverse-probability-of-censoring weights `P(R=1) / P(R=1 | W)` for observed units.
Missing-outcome units receive weight 0.

Uses the existing SuperLearner for the censoring model.
"""
function ipcw_weights(
    df::DataFrame,
    outcome::Symbol,
    covariates::Vector{Symbol};
    learners = (:logistic, :mean),
    folds::Int = 3,
    rng::AbstractRNG = StableRNG(1),
)
    n = nrow(df)
    R = Float64.(.!ismissing.(df[!, outcome]))
    marginal_p = mean(R)

    if marginal_p >= 1.0 - 1e-10
        return ones(n)
    end

    X = design_matrix(df, covariates)
    sl = fit_super_learner(X, R; learners = learners, family = :binomial,
                           metalearner = :invmse, rng = rng)
    p_obs = clamp.(predict_super_learner(sl, X), 1e-3, 1.0 - 1e-3)
    w = marginal_p ./ p_obs
    w[R .== 0.0] .= 0.0
    return w
end

function _column_miss_rates(df::DataFrame, cols::Vector{Symbol})
    n = nrow(df)
    n == 0 && return Dict{Symbol, Float64}(c => NaN for c in cols)
    return Dict{Symbol, Float64}(
        c => count(ismissing, df[!, c]) / n for c in cols
    )
end

function _missing_data_meta(
    strategy::Symbol,
    n_in::Int,
    n_out::Int,
    miss_rates::Dict{Symbol, Float64};
    rung::Symbol = :L2,
    time_indexed::Bool = false,
)
    return (
        strategy = strategy,
        rung = rung,
        time_indexed = time_indexed,
        n_in = n_in,
        n_out = n_out,
        miss_rates = miss_rates,
    )
end

"""
    handle_missing_data(df, outcome, covariates, strategy; learners, folds, rng, rung, time_indexed)
        -> MissingDataResult

Dispatch missing-data handling according to `strategy`:

- `:drop` — complete-case analysis (default, preserves current behaviour)
- `:ipcw` — IPCW for outcome missingness, drop covariate-missing rows
- `:impute` — mean-impute covariates (with indicators), drop outcome-missing rows
- `:ipcw_impute` — both: impute covariates, then IPCW for outcome missingness

Keyword `rung` (default `:L2`) and `time_indexed` are recorded in
`result.meta` for stratum × PCH bookkeeping; they do not change the numerical
policy. Destructure as `data, weights, extra = result` or read `result.meta`.
"""
function handle_missing_data(
    df::DataFrame,
    outcome::Symbol,
    covariates::Vector{Symbol},
    strategy::Symbol;
    learners = (:logistic, :mean),
    folds::Int = 3,
    rng::AbstractRNG = StableRNG(1),
    rung::Symbol = :L2,
    time_indexed::Bool = false,
)
    n_in = nrow(df)
    extra_cols = Symbol[]
    covariates = unique(covariates)
    drop_cols = unique(vcat([outcome], covariates))
    rates = _column_miss_rates(df, drop_cols)

    if strategy == :drop
        df_clean = dropmissing(df, drop_cols)
        meta = _missing_data_meta(
            strategy, n_in, nrow(df_clean), rates;
            rung = rung, time_indexed = time_indexed,
        )
        return MissingDataResult(df_clean, ones(nrow(df_clean)), extra_cols, meta)

    elseif strategy == :ipcw
        df_cc = dropmissing(df, covariates)
        w = ipcw_weights(df_cc, outcome, covariates; learners = learners, folds = folds, rng = rng)
        obs_mask = .!ismissing.(df_cc[!, outcome])
        df_clean = df_cc[obs_mask, :]
        w_clean = w[obs_mask]
        meta = _missing_data_meta(
            strategy, n_in, nrow(df_clean), rates;
            rung = rung, time_indexed = time_indexed,
        )
        return MissingDataResult(df_clean, w_clean, extra_cols, meta)

    elseif strategy == :impute
        df_copy = copy(df)
        indicators = impute_covariates_mean!(df_copy, covariates)
        extra_cols = indicators
        df_clean = dropmissing(df_copy, [outcome])
        meta = _missing_data_meta(
            strategy, n_in, nrow(df_clean), rates;
            rung = rung, time_indexed = time_indexed,
        )
        return MissingDataResult(df_clean, ones(nrow(df_clean)), extra_cols, meta)

    elseif strategy == :ipcw_impute
        df_copy = copy(df)
        indicators = impute_covariates_mean!(df_copy, covariates)
        extra_cols = indicators
        all_covars = vcat(covariates, indicators)
        w = ipcw_weights(df_copy, outcome, all_covars; learners = learners, folds = folds, rng = rng)
        obs_mask = .!ismissing.(df_copy[!, outcome])
        df_clean = df_copy[obs_mask, :]
        w_clean = w[obs_mask]
        meta = _missing_data_meta(
            strategy, n_in, nrow(df_clean), rates;
            rung = rung, time_indexed = time_indexed,
        )
        return MissingDataResult(df_clean, w_clean, extra_cols, meta)
    else
        error("Unknown missing-data strategy: $strategy. Use :drop, :ipcw, :impute, or :ipcw_impute.")
    end
end

"""
    weighted_influence_summary(ic, weights) -> NamedTuple

Hajek weighted mean of an influence-function vector, with IF-scale centred `ic`
and matching SE.

Estimate `est = sum(w .* ψ) / sum(w)`. With `w_bar = mean(w)`, the returned
curve is `ic = (w ./ w_bar) .* (ψ .- est)` and
`se = sqrt(mean(abs2, ic) / n)`, so `se` matches the second moment of `ic`.
"""
function weighted_influence_summary(
    ic::AbstractVector{<:Real},
    weights::AbstractVector{<:Real},
)
    w = Float64.(weights)
    ψ = Float64.(ic)
    n = length(ψ)
    length(w) == n || throw(ArgumentError("length mismatch between ic and weights"))
    sw = sum(w)
    sw ≈ 0 && throw(ArgumentError("weights sum to zero"))
    est = sum(w .* ψ) / sw
    w_bar = sw / n
    ic_adj = (w ./ w_bar) .* (ψ .- est)
    se = n > 1 ? std(ic_adj) / sqrt(n) : NaN
    return (estimate = est, se = se, ic = ic_adj)
end

function _uses_ipcw_weights(weights::AbstractVector{<:Real})
    return !all(w -> isapprox(w, 1.0; atol = 1e-12, rtol = 0.0), weights)
end

"""Key used in DataFrames `metadata` for [`MissingDataResult`](@ref).meta."""
const MISSINGNESS_META_KEY = "causal_targeted_missingness"

"""
    attach_missingness_metadata!(df, meta) -> DataFrame

Store missingness bookkeeping on a grid `DataFrame` via DataFrames metadata.
"""
function attach_missingness_metadata!(df::DataFrame, meta::NamedTuple)
    metadata!(df, MISSINGNESS_META_KEY, meta; style = :note)
    return df
end

"""
    missingness_metadata(x) -> NamedTuple

Read missingness meta from a grid `DataFrame` or a NamedTuple result that
includes a `missingness` field.
"""
function missingness_metadata(df::DataFrame)
    return metadata(df, MISSINGNESS_META_KEY)
end

function missingness_metadata(nt::NamedTuple)
    haskey(nt, :missingness) || throw(ArgumentError(
        "result has no missingness field; update the runner to attach MissingDataResult.meta",
    ))
    return nt.missingness
end

"""
    with_missingness(nt, meta) -> NamedTuple

Merge `missingness = meta` into a NamedTuple estimator result.
"""
with_missingness(nt::NamedTuple, meta::NamedTuple) = (; nt..., missingness = meta)

"""
    mar_set(id::IdentificationResult) -> Vector{Symbol}

Return the MAR conditioning set from `id.missingness`, or an empty vector when
no missingness certificate is attached. Non-breaking adapter for estimators that
prefer reading Structural claims from `identify(...; missingness=)`.
"""
function mar_set(id)
    miss = id.missingness
    miss === nothing && return Symbol[]
    return copy(miss.mar_set)
end

export MissingDataResult, impute_covariates_mean!, ipcw_weights, handle_missing_data
export complete_numeric_column, weighted_influence_summary
export attach_missingness_metadata!, missingness_metadata, with_missingness
export MISSINGNESS_META_KEY, mar_set
