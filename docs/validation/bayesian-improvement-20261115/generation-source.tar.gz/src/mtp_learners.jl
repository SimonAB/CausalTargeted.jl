"""SuperLearner-style nuisance models for MTP estimators.

Default metalearner is cross-validated nonnegative least squares (`:nnls`),
with package-specific simplex normalisation and a squared-loss safeguard; it is
not equivalent to R `method.NNLS` or sl3 `Lrnr_nnls`. Binary outcomes default
to `:nnloglik` (R `method.NNloglik`) at `fit_super_learner`. The discrete
Super Learner (Phillips dSL / sl3 `Lrnr_cv_selector`) is `:cv_selector`.
"""

using DataFrames
using Statistics
using GLM
using Distributions
using Random
using StableRNGs
using Logging

const DEFAULT_SL_LEARNERS = (:glm, :mean)
const COUNT_SL_LEARNERS = (:zeroinflated_nb, :glm_nb, :glm_poisson, :mean)
const SMALL_COUNT_SL_LEARNERS = (:glm_nb, :zeroinflated_nb, :mean)
const DEFAULT_NB_THETA_GRID = (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
const COUNT_OUTCOME_FAMILIES = (:poisson, :negbin, :zeroinflated_nb)
const RICH_SL_LEARNERS = (
    :glm,
    :glm_interact,
    :glm_quad,
    :glmnet,
    :glmnet_lasso,
    :glmnet_ridge,
    :randomforest,
    :evotree,
    :evotree_deep,
    :mean,
)
const NNLOGLIK_TRIM = 1e-5

"""
    validate_contrast_learners(learners; context) -> nothing

Require at least one treatment-dependent Super Learner candidate. `:mean` alone
predicts a constant and cannot identify binary or shift contrasts.
"""
function validate_contrast_learners(learners; context::AbstractString = "contrast estimation")
    candidate_keys = map(_candidate_key, learners)
    if length(candidate_keys) == 1 && only(candidate_keys) === :mean
        throw(ArgumentError(
            "learners=(:mean,) cannot identify treatment contrasts; include at least " *
            "one treatment-dependent learner (e.g. :glm). Context: $context",
        ))
    end
    return nothing
end

"""
    SuperLearnerFit

Typed SuperLearner ensemble: candidate fits, metalearner weights, library names,
and outcome `family` (`:gaussian`, `:binomial`, `:multinomial`, `:poisson`, or
`:negbin`).
"""
struct SuperLearnerFit
    fits::Dict{Symbol, Any}
    weights::Vector{Float64}
    learners::Vector{Symbol}
    metalearner::Symbol
    family::Symbol
    levels::Vector{Any}
end

SuperLearnerFit(
    fits::Dict{Symbol, Any},
    weights::AbstractVector{<:Real},
    learners::AbstractVector{Symbol},
    metalearner::Symbol,
) = SuperLearnerFit(fits, collect(Float64, weights), collect(Symbol, learners),
                     metalearner, :gaussian, Any[])

const NNLS_METALEARNERS = (:nnls, :discrete)
const CV_SELECTOR_METALEARNERS = (:cv_selector, :winner)
const _DISCRETE_METALEARNER_WARNED = Ref(false)

"""Default metalearner for an outcome family (R SuperLearner / sl3)."""
function _default_metalearner(family::Symbol)
    family === :binomial && return :nnloglik
    family === :multinomial && return :nnloglik
    return :nnls
end

"""
    _canonical_metalearner(metalearner; family) -> Symbol

Map aliases: `:discrete` → `:nnls` (deprecated), `:winner` → `:cv_selector`.
"""
function _canonical_metalearner(metalearner::Symbol; family::Symbol = :gaussian)
    if metalearner === :discrete
        if !_DISCRETE_METALEARNER_WARNED[]
            @warn "metalearner=:discrete currently aliases :nnls (cross-validated nonnegative least squares). In CausalTargeted 0.4 it will become the discrete Super Learner (:cv_selector). Pass :nnls or :cv_selector explicitly."
            _DISCRETE_METALEARNER_WARNED[] = true
        end
        return :nnls
    elseif metalearner === :winner
        return :cv_selector
    end
    return metalearner
end

"""
    design_matrix(schema, df; treatment=nothing, treatment_values=nothing) -> Matrix{Float64}

Build `[intercept | optional numeric treatment | encoded covariates]` using a
fitted [`CovariateSchema`](@ref). Treatment is never encoded by the schema.
"""
function design_matrix(
    schema::CovariateSchema,
    df::AbstractDataFrame;
    treatment::Union{Symbol, Nothing} = nothing,
    treatment_values::Union{Nothing, AbstractVector{<:Real}} = nothing,
)
    n = nrow(df)
    encoded = transform_covariates(schema, df)
    p = 1 + Int(treatment !== nothing) + size(encoded, 2)
    X = Matrix{Float64}(undef, n, p)
    X[:, 1] .= 1.0
    col = 2
    if treatment !== nothing
        treatment_values === nothing && _validate_requested_columns(df, [treatment])
        values = treatment_values === nothing ? df[!, treatment] : treatment_values
        length(values) == n || throw(DimensionMismatch(
            "treatment_values length $(length(values)) does not match $n rows",
        ))
        any(ismissing, values) && throw(ArgumentError(
            "treatment :$treatment contains missing values; apply the existing missing-data handling first",
        ))
        @inbounds for i in 1:n
            X[i, col] = try
                Float64(values[i])
            catch
                throw(ArgumentError(
                    "treatment :$treatment must be numeric; categorical treatment is not supported",
                ))
            end
        end
        col += 1
    end
    if !isempty(schema.feature_names)
        X[:, col:end] .= encoded
    end
    return X
end

"""
    design_matrix(df, covariates; treatment=nothing, treatment_values=nothing) -> Matrix{Float64}

Convenience form that fits a covariate schema on `df` and immediately encodes
it. As in earlier releases, requested covariates absent from `df` are ignored.
Cross-fitting code should fit once on the cleaned analysis data and call the
schema-aware method for every fold.
"""
function design_matrix(
    df::AbstractDataFrame,
    covariates::AbstractVector{Symbol};
    treatment::Union{Symbol, Nothing} = nothing,
    treatment_values::Union{Nothing, AbstractVector{<:Real}} = nothing,
)
    present = [covariate for covariate in covariates if hasproperty(df, covariate)]
    fitted_schema = fit_covariate_schema(df, present)
    return design_matrix(
        fitted_schema,
        df;
        treatment = treatment,
        treatment_values = treatment_values,
    )
end

"""
    covariate_design_matrix(df, covariates) -> Matrix{Float64}

Intercept plus covariates only (no treatment column). Reused across δ / counterfactual
predictions via [`outcome_design_matrix`](@ref).
"""
function covariate_design_matrix(df::AbstractDataFrame, covariates::AbstractVector{Symbol})
    return design_matrix(df, covariates; treatment = nothing)
end

function covariate_design_matrix(schema::CovariateSchema, df::AbstractDataFrame)
    return design_matrix(schema, df; treatment = nothing)
end

"""
    outcome_design_matrix(W, a) -> Matrix{Float64}

Assemble `[1 | A | covariates]` from a cached covariate design `W` (intercept +
covariates) and a treatment vector `a` of matching length.
"""
function outcome_design_matrix(W::AbstractMatrix{<:Real}, a::AbstractVector{<:Real})
    n, p = size(W)
    length(a) == n || throw(DimensionMismatch(
        "treatment length $(length(a)) does not match design rows $n",
    ))
    X = Matrix{Float64}(undef, n, p + 1)
    @inbounds for i in 1:n
        X[i, 1] = Float64(W[i, 1])
        X[i, 2] = Float64(a[i])
    end
    if p > 1
        @inbounds for j in 2:p
            for i in 1:n
                X[i, j + 1] = Float64(W[i, j])
            end
        end
    end
    return X
end

"""
    sparse_exposure_diagnostic(a; modal_prop=0.5, min_nonmodal=20) -> NamedTuple
"""
function sparse_exposure_diagnostic(
    a::AbstractVector{<:Real};
    modal_prop::Real = 0.5,
    min_nonmodal::Int = 20,
)
    x = collect(skipmissing(Float64.(a)))
    n = length(x)
    isempty(x) && return (sparse = false, modal_prop = 0.0, modal_count = 0, n = n, n_unique = 0)
    counts = Dict{Float64, Int}()
    for v in x
        counts[v] = get(counts, v, 0) + 1
    end
    modal_count = maximum(values(counts))
    prop = modal_count / n
    nonmodal = n - modal_count
    return (
        sparse = prop >= modal_prop && nonmodal <= min_nonmodal,
        modal_prop = prop,
        modal_count = modal_count,
        n = n,
        n_unique = length(counts),
    )
end

function _safe_mean(y::AbstractVector{<:Real})
    xv = collect(skipmissing(Float64.(y)))
    isempty(xv) && return 0.0
    return mean(xv)
end

"""
    _fit_mlj_regressor(name, X, y)

Internal hook point for MLJ-backed nuisance regression learners.

The default implementation throws; load `MLJ` and `MLJLinearModels` to activate
`CausalTargetedMLJExt`.
"""
function _fit_mlj_regressor(
    name::Symbol,
    X::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real},
)
    error(
        "Requested MLJ learner $name, but MLJ integration is not loaded. " *
        "Run `using MLJ, MLJLinearModels` to activate CausalTargetedMLJExt.",
    )
end

"""
    _predict_mlj_regressor(fit, X)

Internal hook point for MLJ-backed nuisance regression predictions.
Real methods are provided by `CausalTargetedMLJExt`.
"""
function _predict_mlj_regressor(fit, X::AbstractMatrix{<:Real})
    error(
        "MLJ regression prediction requested, but MLJ integration is not loaded. " *
        "Run `using MLJ, MLJLinearModels` to activate CausalTargetedMLJExt.",
    )
end

"""
    _fit_mlj_logistic(X, y)

Internal hook point for MLJ-backed binomial logistic nuisance learners.
"""
function _fit_mlj_logistic(X::AbstractMatrix{<:Real}, y::AbstractVector{<:Real})
    error(
        "Requested MLJ binomial learner, but MLJ integration is not loaded. " *
        "Run `using MLJ, MLJLinearModels` to activate CausalTargetedMLJExt.",
    )
end

"""
    _predict_mlj_logistic(fit, X)

Internal hook point for MLJ-backed binomial logistic predictions.
Real methods are provided by `CausalTargetedMLJExt`.
"""
function _predict_mlj_logistic(fit, X::AbstractMatrix{<:Real})
    error(
        "MLJ logistic prediction requested, but MLJ integration is not loaded. " *
        "Run `using MLJ, MLJLinearModels` to activate CausalTargetedMLJExt.",
    )
end

"""
    _fit_mlj_tree(name, X, y; family)

Internal hook for the controlled MLJ tree learners `:randomforest` and
`:xgboost`. Their package extensions prepare unscaled features, construct the
corresponding regression or probabilistic classification model, and fit it.
"""
function _fit_mlj_tree(
    name::Symbol,
    X::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real};
    family::Symbol,
)
    return _fit_mlj_tree(Val(name), X, y; family = family)
end

function _fit_mlj_tree(
    ::Val{name},
    X::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real};
    family::Symbol,
) where {name}
    packages = name == :randomforest ? "MLJ, MLJDecisionTreeInterface" :
               name == :xgboost ? "MLJ, MLJXGBoostInterface" : "the required MLJ interface"
    error(
        "Requested :$name, but its optional MLJ backend is not loaded. " *
        "Install and run `using $packages` before fitting this learner.",
    )
end

"""
    _predict_mlj_tree(name, fit, X)

Internal prediction hook for optional MLJ tree learners.
"""
function _predict_mlj_tree(name::Symbol, fit, X::AbstractMatrix{<:Real})
    return _predict_mlj_tree(Val(name), fit, X)
end

function _predict_mlj_tree(::Val{name}, fit, X::AbstractMatrix{<:Real}) where {name}
    error(
        "Prediction for :$name requires its optional MLJ backend to remain loaded.",
    )
end

"""
    _drop_intercept_column(X) -> Matrix{Float64}

Remove a leading column of ones if present (design-matrix intercept).
"""
function _drop_intercept_column(X::Matrix{Float64})
    if size(X, 2) >= 1 && all(abs.(view(X, :, 1) .- 1) .< 1e-12)
        return X[:, 2:end]
    end
    return X
end

"""
    _standardise_features(X) -> (Xs, μ, σ)

Column-wise z-score. Constant columns are left unchanged (`μ ← 0`, `σ ← 1`).
"""
function _standardise_features(X::Matrix{Float64})
    n, p = size(X)
    μ = vec(mean(X; dims = 1))
    σ = vec(std(X; dims = 1))
    Xs = Matrix{Float64}(undef, n, p)
    for j in 1:p
        if isfinite(σ[j]) && σ[j] > 1e-8
            Xs[:, j] .= (view(X, :, j) .- μ[j]) ./ σ[j]
        else
            μ[j] = 0.0
            σ[j] = 1.0
            Xs[:, j] .= view(X, :, j)
        end
    end
    return Xs, μ, σ
end

"""
    _apply_feature_standardise(X, μ, σ) -> Matrix{Float64}

Apply a previously fitted column standardisation.
"""
function _apply_feature_standardise(X::Matrix{Float64}, μ::Vector{Float64}, σ::Vector{Float64})
    return (X .- μ') ./ σ'
end

"""
    _prepare_mlj_features(X) -> (Xs, μ, σ)

Drop intercept, then standardise remaining columns.
"""
function _prepare_mlj_features(X::Matrix{Float64})
    Xc = _drop_intercept_column(X)
    size(Xc, 2) == 0 && return ones(size(X, 1), 1), [0.0], [1.0]
    return _standardise_features(Xc)
end

"""
    _prepare_mlj_tree_features(X) -> Matrix{Float64}

Drop the artificial design-matrix intercept without centring or scaling. Tree
backends receive predictors in their original numeric units.
"""
function _prepare_mlj_tree_features(X::Matrix{Float64})
    return _drop_intercept_column(X)
end

"""
    _unpack_mlj_fit(fit) -> (mach, μ, σ)

Accept either a standardised fit NamedTuple or a bare MLJ machine (legacy).
"""
function _unpack_mlj_fit(fit)
    if fit isa NamedTuple && haskey(fit, :mach)
        return fit.mach, fit.μ, fit.σ
    end
    return fit, nothing, nothing
end

"""
    _mlj_feature_matrix(fit, X) -> (mach, Xs)

Rebuild the standardised feature matrix used at fit time (no DataFrame wrap).
"""
function _mlj_feature_matrix(fit, X::Matrix{Float64})
    mach, μ, σ = _unpack_mlj_fit(fit)
    Xc = _drop_intercept_column(X)
    Xs = μ === nothing ? Xc : _apply_feature_standardise(Xc, μ, σ)
    return mach, Xs
end

"""
    _mlj_ext()

Return the optional `CausalTargetedMLJExt` module, or `nothing` if MLJ is not loaded.
"""
function _mlj_ext()
    return Base.get_extension(@__MODULE__, :CausalTargetedMLJExt)
end

"""
    _mljflux_ext()

Return the optional `CausalTargetedMLJFluxExt` module, or `nothing` if MLJFlux
is not loaded.
"""
function _mljflux_ext()
    return Base.get_extension(@__MODULE__, :CausalTargetedMLJFluxExt)
end

"""
    _fit_mlj_mlp(X, y)

Tiny MLP regressor via optional MLJFlux extension (`:mlj_mlp`).
Features are column-standardised before fitting.
"""
function _fit_mlj_mlp(X::Matrix{Float64}, y::Vector{Float64})
    ext = _mljflux_ext()
    ext === nothing && error(
        "Requested :mlj_mlp but MLJFlux is not available. " *
        "Install/load MLJFlux (`using MLJFlux`) to enable neural nuisance learners.",
    )
    Xs, μ, σ = _prepare_mlj_features(X)
    mach = ext.fit_mlp(Xs, y)
    return (mach = mach, μ = μ, σ = σ)
end

"""
    _predict_mlj_mlp(fit, X)

Predict with a fitted `:mlj_mlp` machine (applies train-time standardisation).
"""
function _predict_mlj_mlp(fit, X::Matrix{Float64})
    ext = _mljflux_ext()
    ext === nothing && error("Requested :mlj_mlp prediction but MLJFlux extension is not loaded.")
    mach, μ, σ = _unpack_mlj_fit(fit)
    Xc = _drop_intercept_column(X)
    Xs = μ === nothing ? Xc : _apply_feature_standardise(Xc, μ, σ)
    return ext.predict_mlp(mach, Xs)
end

"""
    _fit_mlj_nn_binary(X, y)

Tiny binary neural classifier via optional MLJFlux extension (`:mlj_nn_binary`).
Features are column-standardised before fitting.
"""
function _fit_mlj_nn_binary(X::Matrix{Float64}, y::Vector{Float64})
    ext = _mljflux_ext()
    ext === nothing && error(
        "Requested :mlj_nn_binary but MLJFlux is not available. " *
        "Install/load MLJFlux (`using MLJFlux`) to enable neural nuisance learners.",
    )
    Xs, μ, σ = _prepare_mlj_features(X)
    mach = ext.fit_nn_binary(Xs, y)
    return (mach = mach, μ = μ, σ = σ)
end

"""
    _predict_mlj_nn_binary(fit, X)

Class-1 probabilities from `:mlj_nn_binary` (applies train-time standardisation).
"""
function _predict_mlj_nn_binary(fit, X::Matrix{Float64})
    ext = _mljflux_ext()
    ext === nothing && error("Requested :mlj_nn_binary prediction but MLJFlux extension is not loaded.")
    mach, μ, σ = _unpack_mlj_fit(fit)
    Xc = _drop_intercept_column(X)
    Xs = μ === nothing ? Xc : _apply_feature_standardise(Xc, μ, σ)
    return ext.predict_nn_binary(mach, Xs)
end

"""
    _fit_evotree_safe(X, y; max_depth, nrounds)

Internal EvoTrees fit. Load `EvoTrees` to activate `CausalTargetedEvoTreesExt`.
"""
function _fit_evotree_safe(
    X::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real};
    max_depth::Int = 2,
    nrounds::Int = 100,
)
    error(
        "Requested an EvoTrees learner, but EvoTrees is not loaded. " *
        "Run `using EvoTrees` to activate CausalTargetedEvoTreesExt.",
    )
end

"""
    _predict_evotree(model, X)

Internal EvoTrees prediction. Real method provided by `CausalTargetedEvoTreesExt`.
"""
function _predict_evotree(model, X::AbstractMatrix{<:Real})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    error(
        "EvoTrees prediction requested, but EvoTrees is not loaded. " *
        "Run `using EvoTrees` to activate CausalTargetedEvoTreesExt.",
    )
end

function _fit_glm_safe(X::Matrix{Float64}, y::Vector{Float64})
    try
        return (:glm, lm(X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _predict_glm(model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return vec(GLM.predict(obj, X))
end

function _fit_logistic_safe(X::Matrix{Float64}, y::Vector{Float64})
    yb = clamp.(Float64.(y), 0.0, 1.0)
    try
        return (:logistic, glm(X, yb, Binomial(), LogitLink()))
    catch
        μ = clamp(_safe_mean(yb), 1e-3, 1 - 1e-3)
        return (:mean, μ)
    end
end

function _predict_logistic(model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return clamp.(vec(GLM.predict(obj, X)), 1e-6, 1 - 1e-6)
end

"""Nonnegative mean fallback for count learners."""
function _safe_mean_count(y::AbstractVector{<:Real})
    return max(_safe_mean(y), 1e-8)
end

function _validate_count_outcome(y::AbstractVector{<:Real})
    all(isfinite, y) ||
        throw(ArgumentError("count outcomes must be finite"))
    any(<(0), y) &&
        throw(ArgumentError("count outcomes must be non-negative"))
    return nothing
end

function _fit_poisson_safe(X::Matrix{Float64}, y::Vector{Float64})
    yc = max.(Float64.(y), 0.0)
    try
        return (:poisson, glm(X, yc, Poisson(), LogLink()))
    catch
        return (:mean, _safe_mean_count(yc))
    end
end

function _predict_poisson(model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return max.(vec(GLM.predict(obj, X)), 1e-8)
end

"""
    _profile_nb_theta(X, y; grid) -> NamedTuple

Select a NegativeBinomial shape parameter by minimum deviance on the training
fold (NB2-style GLM with log link).
"""
function _profile_nb_theta(
    X::Matrix{Float64},
    y::Vector{Float64};
    grid = DEFAULT_NB_THETA_GRID,
)
    yc = max.(Float64.(y), 0.0)
    best_dev = Inf
    best_model = nothing
    best_θ = 2.0
    for θ in grid
        try
            m = glm(X, yc, NegativeBinomial(θ), LogLink())
            dev = deviance(m)
            if dev < best_dev
                best_dev = dev
                best_model = m
                best_θ = θ
            end
        catch
        end
    end
    best_model === nothing && return _fit_poisson_safe(X, y)
    return (:negbin, (model = best_model, θ = best_θ))
end

function _fit_negbin_safe(
    X::Matrix{Float64},
    y::Vector{Float64};
    θ::Union{Nothing, Real} = nothing,
)
    yc = max.(Float64.(y), 0.0)
    if θ !== nothing
        try
            m = glm(X, yc, NegativeBinomial(Float64(θ)), LogLink())
            return (:negbin, (model = m, θ = Float64(θ)))
        catch
            return (:mean, _safe_mean_count(yc))
        end
    end
    return _profile_nb_theta(X, y)
end

"""
    _fit_zeroinflated_nb_safe(X, y) -> Tuple

Zero-inflated NB learner: logistic inflation on ``I(y=0)`` plus profiled NB
on counts. Predictions use ``(1 - \\hat\\pi) \\hat\\mu`` (composite mean).
"""
function _fit_zeroinflated_nb_safe(X::Matrix{Float64}, y::Vector{Float64})
    yc = max.(Float64.(y), 0.0)
    z = Float64.(yc .== 0)
    pi_model = try
        m = glm(X, z, Binomial(), LogitLink())
        (:logistic, m)
    catch
        (:mean, _safe_mean(z))
    end
    nb_model = _fit_negbin_safe(X, yc)
    return (:zeroinflated_nb, (pi = pi_model, nb = nb_model))
end

function _predict_zeroinflated_nb(model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    pi_pred = if obj.pi[1] == :mean
        fill(Float64(obj.pi[2]), size(X, 1))
    else
        clamp.(vec(GLM.predict(obj.pi[2], X)), 1e-8, 1 - 1e-8)
    end
    mu = _predict_negbin(obj.nb, X)
    return max.((1 .- pi_pred) .* mu, 0.0)
end

function _predict_negbin(model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return max.(vec(GLM.predict(obj.model, X)), 1e-8)
end

"""
    _expand_interactions(X) -> Matrix{Float64}

Append all pairwise interaction columns X_i·X_j (i < j) to the design matrix.
"""
function _expand_interactions(X::Matrix{Float64})
    n, p = size(X)
    n_pairs = p * (p - 1) ÷ 2
    n_pairs == 0 && return X
    out = Matrix{Float64}(undef, n, p + n_pairs)
    @inbounds out[:, 1:p] .= X
    col = p + 1
    @inbounds for i in 1:p
        for j in (i + 1):p
            for r in 1:n
                out[r, col] = X[r, i] * X[r, j]
            end
            col += 1
        end
    end
    return out
end

"""
    _expand_quadratic(X) -> Matrix{Float64}

Append X_i² columns to the design matrix.
"""
function _expand_quadratic(X::Matrix{Float64})
    n, p = size(X)
    out = Matrix{Float64}(undef, n, 2p)
    @inbounds out[:, 1:p] .= X
    @inbounds for j in 1:p
        for r in 1:n
            out[r, p + j] = X[r, j]^2
        end
    end
    return out
end

"""
    NestedSLCandidate(name, learners, metalearner)

An ensemble Super Learner treated as one discrete-SL candidate (Phillips
eSL-inside-dSL). Outer `fit_super_learner` must use `metalearner=:cv_selector`.
Inner ensembles may not themselves be `:cv_selector` or contain nested candidates.
LMTP density-ratio classifiers stay on `:invmse` and should not use this type.
"""
struct NestedSLCandidate
    name::Symbol
    learners::Vector{Symbol}
    metalearner::Symbol
end

"""
    nested_sl_candidate(learners; name=:esl, metalearner=:nnls) -> NestedSLCandidate

Build a nested ensemble candidate for `metalearner=:cv_selector`.
"""
function nested_sl_candidate(
    learners;
    name::Symbol = :esl,
    metalearner::Symbol = :nnls,
)
    inner = collect(Symbol, learners)
    isempty(inner) && throw(ArgumentError("nested_sl_candidate requires at least one learner"))
    metalearner === :cv_selector && throw(ArgumentError(
        "nested SL inner metalearner cannot be :cv_selector; use :nnls or :nnloglik",
    ))
    return NestedSLCandidate(name, inner, metalearner)
end

_candidate_key(c::Symbol) = c
_candidate_key(c::NestedSLCandidate) = c.name

function _fit_any_candidate(c::Symbol, X, y; family)
    return _fit_learner(c, X, y; family = family)
end

function _fit_any_candidate(c::NestedSLCandidate, X, y; family)
    return fit_super_learner(
        X, y;
        learners = c.learners,
        metalearner = c.metalearner,
        family = family,
    )
end

function _fit_learner(name::Symbol, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    # Preserve legacy behaviour: under `family=:binomial`, `:mean` is a logistic
    # probability estimator on {0,1}.
    if family == :binomial && name == :mean
        return _fit_logistic_safe(X, y)
    end
    return _fit_learner(Val(name), X, y; family = family)
end

function _fit_learner(::Val{name}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian) where {name}
    error("Unknown learner $name")
end

function _fit_learner(::Val{:logistic}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial || return (:mean, _safe_mean(y))
    return _fit_logistic_safe(X, y)
end

function _fit_learner(::Val{:mlj_logistic}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial || return (:mean, _safe_mean(y))
    try
        return (:mlj_logistic, _fit_mlj_logistic(X, y))
    catch
        return _fit_logistic_safe(X, y)
    end
end

function _fit_learner(::Val{:mlj_mlp}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:mlj_mlp, _fit_mlj_mlp(X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:mlj_nn_binary}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial || return (:mean, _safe_mean(y))
    try
        return (:mlj_nn_binary, _fit_mlj_nn_binary(X, y))
    catch
        return _fit_logistic_safe(X, y)
    end
end

function _fit_learner(::Val{:mlj_ridge}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:mlj_ridge, _fit_mlj_regressor(:mlj_ridge, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:mlj_lasso}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:mlj_lasso, _fit_mlj_regressor(:mlj_lasso, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:mlj_elasticnet}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:mlj_elasticnet, _fit_mlj_regressor(:mlj_elasticnet, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:randomforest}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family in (:gaussian, :binomial, :multinomial, :poisson, :negbin, :zeroinflated_nb) || throw(ArgumentError(
        ":randomforest supports family=:gaussian, :binomial, :multinomial, :poisson, :negbin, or :zeroinflated_nb; got $family",
    ))
    tree_family = family in COUNT_OUTCOME_FAMILIES ? :gaussian : family
    return (:randomforest, _fit_mlj_tree(:randomforest, X, y; family = tree_family))
end

function _fit_learner(::Val{:xgboost}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family in (:gaussian, :binomial, :multinomial, :poisson, :negbin, :zeroinflated_nb) || throw(ArgumentError(
        ":xgboost supports family=:gaussian, :binomial, :multinomial, :poisson, :negbin, or :zeroinflated_nb; got $family",
    ))
    tree_family = family in COUNT_OUTCOME_FAMILIES ? :gaussian : family
    return (:xgboost, _fit_mlj_tree(:xgboost, X, y; family = tree_family))
end

"""Fit a GLM on an already-expanded design (Gaussian, logistic, Poisson, or NB)."""
function _fit_glm_design(X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family === :binomial && return _fit_logistic_safe(X, y)
    family === :poisson && return _fit_poisson_safe(X, y)
    family === :negbin && return _fit_negbin_safe(X, y)
    family === :zeroinflated_nb && return _fit_zeroinflated_nb_safe(X, y)
    return _fit_glm_safe(X, y)
end

"""Predict from a nested GLM / count / logistic / `mean` fallback tuple."""
function _predict_glm_design(inner, X::Matrix{Float64})
    typ = inner[1]
    typ === :logistic && return _predict_logistic(inner, X)
    typ === :poisson && return _predict_poisson(inner, X)
    typ === :negbin && return _predict_negbin(inner, X)
    typ === :zeroinflated_nb && return _predict_zeroinflated_nb(inner, X)
    return _predict_glm(inner, X)
end

function _fit_learner(::Val{:glm}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_glm_design(X, y; family = family)
end

function _fit_learner(::Val{:glm_poisson}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_poisson_safe(X, y)
end

function _fit_learner(::Val{:glm_nb}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_negbin_safe(X, y)
end

function _fit_learner(::Val{:zeroinflated_nb}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_zeroinflated_nb_safe(X, y)
end

function _fit_learner(::Val{:glm_interact}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return (:glm_interact, _fit_glm_design(_expand_interactions(X), y; family = family))
end

function _fit_learner(::Val{:glm_quad}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return (:glm_quad, _fit_glm_design(_expand_quadratic(X), y; family = family))
end

function _fit_learner(::Val{:glmnet}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:glmnet, _fit_mlj_regressor(:mlj_elasticnet, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:glmnet_lasso}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:glmnet_lasso, _fit_mlj_regressor(:mlj_lasso, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:glmnet_ridge}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    family == :binomial && return (:mean, _safe_mean(y))
    try
        return (:glmnet_ridge, _fit_mlj_regressor(:mlj_ridge, X, y))
    catch
        return (:mean, _safe_mean(y))
    end
end

function _fit_learner(::Val{:evotree}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_evotree_safe(X, y; max_depth = 2)
end

function _fit_learner(::Val{:evotree_deep}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return _fit_evotree_safe(X, y; max_depth = 4, nrounds = 150)
end

function _fit_learner(::Val{:mean}, X::Matrix{Float64}, y::Vector{Float64}; family = :gaussian)
    return (:mean, _safe_mean(y))
end

function _predict_learner(model, X::Matrix{Float64})
    model isa SuperLearnerFit && return predict_super_learner(model, X)
    return _predict_learner(Val(model[1]), model, X)
end

function _predict_learner(::Val{:glm}, model, X::Matrix{Float64})
    return _predict_glm_design(model, X)
end

function _predict_learner(::Val{:glm_poisson}, model, X::Matrix{Float64})
    return _predict_poisson(model, X)
end

function _predict_learner(::Val{:glm_nb}, model, X::Matrix{Float64})
    return _predict_negbin(model, X)
end

function _predict_learner(::Val{:zeroinflated_nb}, model, X::Matrix{Float64})
    return _predict_zeroinflated_nb(model, X)
end

function _predict_learner(::Val{:glm_interact}, model, X::Matrix{Float64})
    return _predict_glm_design(model[2], _expand_interactions(X))
end

function _predict_learner(::Val{:glm_quad}, model, X::Matrix{Float64})
    return _predict_glm_design(model[2], _expand_quadratic(X))
end

function _predict_learner(::Val{:glmnet}, model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return _predict_mlj_regressor(obj, X)
end

function _predict_learner(::Val{:glmnet_lasso}, model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return _predict_mlj_regressor(obj, X)
end

function _predict_learner(::Val{:glmnet_ridge}, model, X::Matrix{Float64})
    typ, obj = model
    typ == :mean && return fill(Float64(obj), size(X, 1))
    return _predict_mlj_regressor(obj, X)
end

function _predict_learner(::Val{:evotree}, model, X::Matrix{Float64})
    return _predict_evotree(model, X)
end

function _predict_learner(::Val{:mlj_ridge}, model, X::Matrix{Float64})
    return _predict_mlj_regressor(model[2], X)
end

function _predict_learner(::Val{:mlj_lasso}, model, X::Matrix{Float64})
    return _predict_mlj_regressor(model[2], X)
end

function _predict_learner(::Val{:mlj_elasticnet}, model, X::Matrix{Float64})
    return _predict_mlj_regressor(model[2], X)
end

function _predict_learner(::Val{:mlj_mlp}, model, X::Matrix{Float64})
    return _predict_mlj_mlp(model[2], X)
end

function _predict_learner(::Val{:logistic}, model, X::Matrix{Float64})
    return _predict_logistic(model, X)
end

function _predict_learner(::Val{:mlj_logistic}, model, X::Matrix{Float64})
    return _predict_mlj_logistic(model[2], X)
end

function _predict_learner(::Val{:mlj_nn_binary}, model, X::Matrix{Float64})
    return _predict_mlj_nn_binary(model[2], X)
end

function _predict_learner(::Val{:randomforest}, model, X::Matrix{Float64})
    return _predict_mlj_tree(:randomforest, model[2], X)
end

function _predict_learner(::Val{:xgboost}, model, X::Matrix{Float64})
    return _predict_mlj_tree(:xgboost, model[2], X)
end

function _predict_learner(::Val{:poisson}, model, X::Matrix{Float64})
    return _predict_poisson(model, X)
end

function _predict_learner(::Val{:negbin}, model, X::Matrix{Float64})
    return _predict_negbin(model, X)
end

function _predict_learner(::Val{typ}, model, X::Matrix{Float64}) where {typ}
    return fill(Float64(model[2]), size(X, 1))
end

"""
    _cv_selector_weights(Z, y) -> Vector{Float64}

Discrete Super Learner (Phillips dSL / sl3 `Lrnr_cv_selector`): one-hot weight
on the candidate with lowest cross-validated squared error (Brier).
"""
function _cv_selector_weights(Z::Matrix{Float64}, y::Vector{Float64})
    k = size(Z, 2)
    k == 0 && return Float64[]
    mse = [mean((Z[:, j] .- y) .^ 2) for j in 1:k]
    for j in 1:k
        isfinite(mse[j]) || (mse[j] = Inf)
    end
    w = zeros(k)
    w[argmin(mse)] = 1.0
    return w
end

"""
    _nonneg_ls_weights(Z, y) -> Vector{Float64}

Coordinate-descent nonnegative least squares followed by normalisation to
simplex weights. Because normalising the unconstrained NNLS coefficients can
increase squared prediction loss, compare that blend with each single
candidate on the same predictions and return the best candidate if it has lower
loss. This package-specific safeguard is not equivalent to R
`SuperLearner::method.NNLS` or sl3 `Lrnr_nnls`.
"""
function _nonneg_ls_weights(Z::Matrix{Float64}, y::Vector{Float64})
    k = size(Z, 2)
    k == 0 && return Float64[]
    # Coordinate descent NNLS on min ||y - Z w||², w ≥ 0, then renormalise.
    w = fill(1 / k, k)
    for _ in 1:200
        r = y .- Z * w
        for j in 1:k
            zj = Z[:, j]
            denom = sum(abs2, zj)
            denom < 1e-12 && continue
            w[j] = max(0.0, w[j] + sum(zj .* r) / denom)
            r = y .- Z * w
        end
    end
    s = sum(w)
    normalised = s > 0 ? w ./ s : fill(1 / k, k)
    blend_risk = mean(abs2, Z * normalised .- y)
    candidate_risks = [mean(abs2, Z[:, j] .- y) for j in 1:k]
    best_candidate = argmin(candidate_risks)
    if !(blend_risk <= candidate_risks[best_candidate])
        fallback = zeros(k)
        fallback[best_candidate] = 1.0
        return fallback
    end
    return normalised
end

function _invmse_weights(Z::Matrix{Float64}, y::Vector{Float64})
    k = size(Z, 2)
    mse = [mean((Z[:, j] .- y) .^ 2) for j in 1:k]
    inv = [isfinite(m) && m > 1e-12 ? 1 / m : 0.0 for m in mse]
    s = sum(inv)
    return s > 0 ? inv ./ s : fill(1 / k, k)
end

function _validate_binary_outcome(y::AbstractVector{<:Real})
    all(isfinite, y) || throw(ArgumentError("NNloglik outcomes must be finite and equal to 0 or 1"))
    all(v -> v == 0 || v == 1, y) ||
        throw(ArgumentError("NNloglik requires a binary outcome containing only 0 and 1"))
    return nothing
end

"""
    validate_family_outcome(y, family) -> nothing

Check that `family` is a supported Super Learner outcome family and that
`:binomial` outcomes lie in ``\\{0, 1\\}``.
"""
function validate_family_outcome(y::AbstractVector, family::Symbol)
    family in (:gaussian, :binomial, :multinomial, :poisson, :negbin, :zeroinflated_nb) ||
        throw(ArgumentError(
        "family_outcome must be :gaussian, :binomial, :multinomial, :poisson, " *
        ":negbin, or :zeroinflated_nb; got $family",
    ))
    family === :binomial && _validate_binary_outcome(collect(Float64, y))
    family in COUNT_OUTCOME_FAMILIES && _validate_count_outcome(collect(Float64, y))
    return nothing
end

"""Return true when values look like nonnegative integer counts (not binary)."""
function _looks_like_count_vals(vals::AbstractVector{<:Real})
    isempty(vals) && return false
    all(v -> v >= 0, vals) || return false
    all(v -> abs(v - round(v)) < 1e-8, vals) || return false
    return !(maximum(vals) <= 1 && all(v -> v == 0 || v == 1, vals))
end

"""
    suggest_family_outcome(y) -> Symbol

Return `:binomial` when all non-missing values lie in ``\\{0, 1\\}``;
`:negbin` or `:poisson` for nonnegative integer counts (overdispersion heuristic);
otherwise `:gaussian`. Use with `recommend_run_options(...; outcome=)` or pass
the result as `family_outcome` on LMTP runners
([#34](https://github.com/SimonAB/CausalTargeted.jl/issues/34),
[#36](https://github.com/SimonAB/CausalTargeted.jl/issues/36)).
"""
function suggest_family_outcome(y::AbstractVector)
    vals = Float64[]
    for v in y
        ismissing(v) && continue
        push!(vals, Float64(v))
    end
    isempty(vals) && return :gaussian
    if maximum(vals) <= 1 && all(v -> v == 0.0 || v == 1.0, vals)
        return :binomial
    end
    if _looks_like_count_vals(vals)
        μ = mean(vals)
        σ² = var(vals; corrected = true)
        return σ² > μ * 1.25 + 1e-8 ? :negbin : :poisson
    end
    return :gaussian
end

"""Trim a probability matrix and return its elementwise logits."""
function _trim_logit_predictions(
    Z::AbstractMatrix{<:Real};
    trim::Real = NNLOGLIK_TRIM,
)
    0 < trim < 0.5 || throw(ArgumentError("trim must lie strictly between 0 and 0.5"))
    all(isfinite, Z) || throw(ArgumentError("NNloglik learner predictions must be finite"))
    all(p -> 0 <= p <= 1, Z) ||
        throw(ArgumentError("NNloglik learner predictions must lie in [0, 1]"))
    lower = Float64(trim)
    upper = 1.0 - lower
    Xlogit = Matrix{Float64}(undef, size(Z))
    @inbounds for idx in eachindex(Z)
        p = clamp(Float64(Z[idx]), lower, upper)
        Xlogit[idx] = log(p) - log1p(-p)
    end
    return Xlogit
end

@inline function _logistic(eta::Float64)
    if eta >= 0
        z = exp(-eta)
        return 1 / (1 + z)
    end
    z = exp(eta)
    return z / (1 + z)
end

@inline _log1pexp(x::Float64) = max(x, 0.0) + log1p(exp(-abs(x)))

"""Weighted mean Bernoulli negative log likelihood from a logit design."""
function _nnloglik_objective(
    beta::AbstractVector{<:Real},
    Xlogit::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real},
    obs_weights::AbstractVector{<:Real},
)
    eta = Xlogit * beta
    total_weight = sum(obs_weights)
    loss = 0.0
    @inbounds for i in eachindex(y)
        loss += Float64(obs_weights[i]) *
                (_log1pexp(Float64(eta[i])) - Float64(y[i]) * Float64(eta[i]))
    end
    return loss / total_weight
end

"""Analytic gradient of `_nnloglik_objective`."""
function _nnloglik_gradient(
    beta::AbstractVector{<:Real},
    Xlogit::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real},
    obs_weights::AbstractVector{<:Real},
)
    eta = Xlogit * beta
    residual = Vector{Float64}(undef, length(y))
    @inbounds for i in eachindex(y)
        residual[i] = Float64(obs_weights[i]) *
                      (_logistic(Float64(eta[i])) - Float64(y[i]))
    end
    return vec(transpose(Xlogit) * residual) ./ sum(obs_weights)
end

"""
    _nnloglik_fit(Z, y; obs_weights, trim, tol, maxiter)

Fit non-negative logit-combination coefficients with deterministic projected
gradient descent and Armijo backtracking. The returned `weights` are normalised
when the fitted coefficient sum is positive; `raw_weights` retain the optimiser
scale for numerical QC.
"""
function _nnloglik_fit(
    Z::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real};
    obs_weights::AbstractVector{<:Real} = ones(length(y)),
    trim::Real = NNLOGLIK_TRIM,
    tol::Real = 1e-8,
    maxiter::Int = 10_000,
)
    n, k = size(Z)
    n == length(y) || throw(DimensionMismatch("prediction rows must match outcome length"))
    length(obs_weights) == n ||
        throw(DimensionMismatch("observation weights must match outcome length"))
    k > 0 || throw(ArgumentError("NNloglik requires at least one candidate learner"))
    tol > 0 || throw(ArgumentError("tol must be positive"))
    maxiter > 0 || throw(ArgumentError("maxiter must be positive"))
    _validate_binary_outcome(y)
    all(isfinite, obs_weights) ||
        throw(ArgumentError("NNloglik observation weights must be finite"))
    all(w -> w >= 0, obs_weights) ||
        throw(ArgumentError("NNloglik observation weights must be non-negative"))
    sum(obs_weights) > 0 ||
        throw(ArgumentError("NNloglik observation weights must have a positive sum"))

    Xlogit = _trim_logit_predictions(Z; trim = trim)
    beta = fill(1 / k, k)
    objective = _nnloglik_objective(beta, Xlogit, y, obs_weights)
    isfinite(objective) || error("NNloglik optimisation started from a non-finite objective")
    gradient = _nnloglik_gradient(beta, Xlogit, y, obs_weights)
    previous_beta = copy(beta)
    previous_gradient = copy(gradient)
    step = 1.0
    converged = false
    iterations = 0

    for iteration in 1:maxiter
        iterations = iteration
        projected_gradient = beta .- max.(0.0, beta .- gradient)
        if maximum(abs, projected_gradient) <= tol * (1 + maximum(abs, beta))
            converged = true
            break
        end

        if iteration > 1
            delta_beta = beta .- previous_beta
            delta_gradient = gradient .- previous_gradient
            curvature = sum(delta_beta .* delta_gradient)
            if curvature > 0
                step = clamp(sum(abs2, delta_beta) / curvature, 1e-12, 1e6)
            else
                step = 1.0
            end
        end

        previous_beta .= beta
        previous_gradient .= gradient
        accepted = false
        trial_beta = similar(beta)
        trial_objective = objective
        for _ in 1:60
            trial_beta .= max.(0.0, beta .- step .* gradient)
            direction = trial_beta .- beta
            trial_objective = _nnloglik_objective(trial_beta, Xlogit, y, obs_weights)
            if isfinite(trial_objective) &&
               trial_objective <= objective + 1e-4 * sum(gradient .* direction)
                accepted = true
                break
            end
            step *= 0.5
        end
        accepted || error(
            "NNloglik optimisation failed to find a finite descent step at iteration $iteration",
        )

        beta .= trial_beta
        objective = trial_objective
        gradient = _nnloglik_gradient(beta, Xlogit, y, obs_weights)
        all(isfinite, gradient) ||
            error("NNloglik optimisation produced a non-finite gradient")
    end

    converged || error(
        "NNloglik optimisation did not converge within $maxiter iterations " *
        "(projected-gradient tolerance $tol)",
    )
    all(isfinite, beta) || error("NNloglik optimisation produced non-finite coefficients")
    beta .= max.(beta, 0.0)
    coefficient_sum = sum(beta)
    weights = coefficient_sum > 0 ? beta ./ coefficient_sum : copy(beta)
    return (
        weights = weights,
        raw_weights = beta,
        objective = objective,
        iterations = iterations,
        converged = converged,
    )
end

function _nnloglik_weights(
    Z::AbstractMatrix{<:Real},
    y::AbstractVector{<:Real};
    kwargs...,
)
    return _nnloglik_fit(Z, y; kwargs...).weights
end

"""Combine probability columns as a convex combination of their logits."""
function _predict_nnloglik(
    Z::AbstractMatrix{<:Real},
    weights::AbstractVector{<:Real};
    trim::Real = NNLOGLIK_TRIM,
)
    size(Z, 2) == length(weights) ||
        throw(DimensionMismatch("prediction columns must match NNloglik weights"))
    all(isfinite, weights) || throw(ArgumentError("NNloglik weights must be finite"))
    Xlogit = _trim_logit_predictions(Z; trim = trim)
    eta = Xlogit * weights
    return [_logistic(Float64(value)) for value in eta]
end

"""
    TabularSuperLearnerFit

Super Learner fit paired with the fitted covariate schema used to construct its
numeric design matrix.
"""
struct TabularSuperLearnerFit
    fit::SuperLearnerFit
    schema::CovariateSchema
    covariates::Vector{Symbol}
    treatment::Union{Nothing, Symbol}
end

"""
    _fit_sl_outcome(df, cols, y; treatment, learners, rng, schema) -> TabularSuperLearnerFit

Fit a Super Learner on `design_matrix(df, cols; treatment)`. Used by g-computation,
sequential LMTP, and (via CausalMediation) mediation nuisances.
"""
function _fit_sl_outcome(
    df::DataFrame,
    cols::Vector{Symbol},
    y::AbstractVector{<:Real};
    treatment = nothing,
    learners = DEFAULT_SL_LEARNERS,
    rng = StableRNG(1),
    schema::Union{Nothing, CovariateSchema} = nothing,
)
    fitted_schema = schema === nothing ? fit_covariate_schema(df, cols) : schema
    fitted_schema.covariates == cols || throw(ArgumentError(
        "provided schema covariates $(repr(fitted_schema.covariates)) do not match $(repr(cols))",
    ))
    X = design_matrix(fitted_schema, df; treatment = treatment)
    fit = fit_super_learner(X, Float64.(y); learners = learners, rng = rng)
    return TabularSuperLearnerFit(fit, fitted_schema, copy(cols), treatment)
end

"""Predict from a Super Learner fit on a design matrix for `cols`."""
function _predict_sl(
    sl::TabularSuperLearnerFit,
    df::DataFrame,
    cols::Vector{Symbol};
    treatment = nothing,
    treatment_values = nothing,
)
    cols == sl.covariates || throw(ArgumentError(
        "prediction covariates $(repr(cols)) do not match fitted covariates $(repr(sl.covariates))",
    ))
    treatment == sl.treatment || throw(ArgumentError(
        "prediction treatment $(repr(treatment)) does not match fitted treatment $(repr(sl.treatment))",
    ))
    X = design_matrix(
        sl.schema,
        df;
        treatment = treatment,
        treatment_values = treatment_values,
    )
    return predict_super_learner(sl.fit, X)
end

"""
    fit_super_learner(X, y; learners, metalearner, folds, rng, family) -> SuperLearnerFit

Fit candidate learners and combine with a metalearner.

- `:nnls` — cross-validated nonnegative least squares, normalised to simplex
  weights with a same-prediction squared-loss check that falls back to the best
  single candidate when normalisation worsens the blend (default for
  `family=:gaussian`). This package-specific version is not equivalent to R
  `SuperLearner::method.NNLS` or sl3 `Lrnr_nnls`.
- `:nnloglik` — nonnegative Bernoulli (or multinomial) log-likelihood on the
  logit / probability simplex (default for `family=:binomial`; R `method.NNloglik`)
- `:cv_selector` — discrete Super Learner: one-hot on the CV-best candidate
  (Phillips dSL / sl3 `Lrnr_cv_selector`). Alias: `:winner`. Candidates may
  include [`nested_sl_candidate`](@ref) ensembles (eSL-inside-dSL).
- `:invmse` — inverse training MSE weights (fast fallback; LMTP classifiers)
- `:discrete` — **deprecated** alias of `:nnls` (will become `:cv_selector` in 0.4)

The NNloglik prediction rule for binary outcomes is
`logistic(sum(w[j] * logit(p[j])))`, not an arithmetic mean of probabilities.
It is independently implemented from the same statistical construction as R
`SuperLearner::method.NNloglik`, which can serve as an external numerical QC
benchmark.

Squared error remains a proper scoring rule for binary probabilities; NNloglik
is an alternative rather than a universally superior criterion. Its stronger
penalty for overconfident errors can be useful when fitted probabilities feed
propensity scores, density ratios, censoring or missingness models, or other
odds-sensitive calculations.
"""
function fit_super_learner(
    X::Matrix{Float64},
    y::AbstractVector;
    learners = DEFAULT_SL_LEARNERS,
    metalearner::Union{Symbol, Nothing} = nothing,
    folds::Int = 3,
    rng = StableRNG(42),
    family::Symbol = :gaussian,
    levels = nothing,
)
    family in (:gaussian, :binomial, :multinomial, :poisson, :negbin, :zeroinflated_nb) || throw(ArgumentError(
        "unknown family $family; expected :gaussian, :binomial, :multinomial, :poisson, :negbin, or :zeroinflated_nb",
    ))
    requested = metalearner === nothing ? _default_metalearner(family) : metalearner
    canon = _canonical_metalearner(requested; family = family)
    canon in (:nnls, :invmse, :nnloglik, :cv_selector) || throw(ArgumentError(
        "unknown metalearner $requested; expected :nnls, :nnloglik, :cv_selector, :invmse, or deprecated :discrete",
    ))
    if family === :multinomial
        return _fit_multinomial_super_learner(
            X, y; learners = learners, metalearner = canon,
            folds = folds, rng = rng, levels = levels,
        )
    end
    yf = collect(Float64, y)
    if canon === :nnloglik
        family === :binomial || throw(ArgumentError(
            "metalearner=:nnloglik requires family=:binomial or family=:multinomial",
        ))
        _validate_binary_outcome(yf)
    end
    n = length(yf)
    candidates = collect(learners)
    keys = [_candidate_key(c) for c in candidates]
    length(unique(keys)) == length(keys) || throw(ArgumentError(
        "Super Learner candidate names must be unique; got $keys",
    ))
    if any(c -> c isa NestedSLCandidate, candidates)
        canon === :cv_selector || throw(ArgumentError(
            "nested_sl_candidate is only valid under metalearner=:cv_selector " *
            "(Phillips eSL-inside-dSL); got $canon",
        ))
    end
    k = length(candidates)
    Z = zeros(n, k)
    use_cv = canon in (:nnls, :nnloglik, :cv_selector) && n >= 2 * folds
    if use_cv
        fold_sets = crossfit_indices(n, folds, rng)
        for test_idx in fold_sets
            train_idx = setdiff(1:n, test_idx)
            Xtr = X[train_idx, :]
            ytr = yf[train_idx]
            Xte = X[test_idx, :]
            for (j, c) in enumerate(candidates)
                m = _fit_any_candidate(c, Xtr, ytr; family = family)
                Z[test_idx, j] = _predict_learner(m, Xte)
            end
        end
    else
        for (j, c) in enumerate(candidates)
            m = _fit_any_candidate(c, X, yf; family = family)
            Z[:, j] = _predict_learner(m, X)
        end
    end
    weights = if canon === :nnloglik
        _nnloglik_weights(Z, yf)
    elseif canon === :cv_selector && use_cv
        _cv_selector_weights(Z, yf)
    elseif canon === :nnls && use_cv
        _nonneg_ls_weights(Z, yf)
    else
        _invmse_weights(Z, yf)
    end
    fits = Dict{Symbol, Any}()
    for (key, c) in zip(keys, candidates)
        fits[key] = _fit_any_candidate(c, X, yf; family = family)
    end
    return SuperLearnerFit(fits, weights, keys, canon, family, Any[])
end

"""
    predict_super_learner(sl, X) -> Vector{Float64}
"""
function predict_super_learner(sl::SuperLearnerFit, X::Matrix{Float64})
    sl.family === :multinomial && return _predict_multinomial_super_learner(sl, X)
    n = size(X, 1)
    if sl.metalearner == :nnloglik
        Z = Matrix{Float64}(undef, n, length(sl.learners))
        for (j, lrn) in enumerate(sl.learners)
            Z[:, j] = _predict_learner(sl.fits[lrn], X)
        end
        return _predict_nnloglik(Z, sl.weights)
    end
    out = zeros(n)
    for (j, lrn) in enumerate(sl.learners)
        out .+= sl.weights[j] .* _predict_learner(sl.fits[lrn], X)
    end
    if sl.family in COUNT_OUTCOME_FAMILIES
        out .= max.(out, 0.0)
    end
    return out
end

# Compat for NamedTuple fits from older call sites / notebooks
function predict_super_learner(sl::NamedTuple, X::Matrix{Float64})
    family = hasproperty(sl, :family) ? sl.family : :gaussian
    levels = hasproperty(sl, :levels) ? collect(Any, sl.levels) : Any[]
    return predict_super_learner(
        SuperLearnerFit(
            sl.fits, collect(Float64, sl.weights), collect(Symbol, sl.learners),
            sl.metalearner, family, levels,
        ),
        X,
    )
end

"""
    _crossfit_super_learner(df, target, covariates, folds, rng; kwargs...) -> Vector{Float64}

Cross-fit a Super Learner for `target` and return out-of-fold predictions.

The covariate schema is fitted once on the full frame; each fold then trains on
its complement and predicts the held-out rows. `treatment`, when given, enters
the design matrix as a numeric column. `treatment_values` substitutes
counterfactual exposures on the test rows only, leaving training on the observed
exposure. `fold_sets` reuses an existing partition instead of drawing a new one,
and `clamp_to` bounds the predictions (used for propensities).
"""
function _crossfit_super_learner(
    df::DataFrame,
    target::AbstractVector{<:Real},
    covariates::Vector{Symbol},
    folds::Int,
    rng;
    treatment::Union{Symbol, Nothing} = nothing,
    treatment_values::Union{Nothing, AbstractVector{<:Real}} = nothing,
    learners = DEFAULT_SL_LEARNERS,
    family::Symbol = :gaussian,
    metalearner::Union{Symbol, Nothing} = nothing,
    clamp_to::Union{Nothing, Tuple{Real, Real}} = nothing,
    fold_sets = nothing,
)
    n = nrow(df)
    y = Float64.(target)
    preds = zeros(n)
    schema = fit_covariate_schema(df, covariates)
    sets = fold_sets === nothing ? crossfit_indices(n, folds, rng) : fold_sets
    for test_idx in sets
        train_idx = setdiff(1:n, test_idx)
        Xtr = design_matrix(schema, df[train_idx, :]; treatment = treatment)
        Xte = design_matrix(
            schema, df[test_idx, :];
            treatment = treatment,
            treatment_values = treatment_values === nothing ?
                nothing : treatment_values[test_idx],
        )
        sl = fit_super_learner(
            Xtr, y[train_idx];
            learners = learners, family = family,
            metalearner = metalearner, rng = rng,
        )
        raw = predict_super_learner(sl, Xte)
        preds[test_idx] = clamp_to === nothing ? raw : clamp.(raw, clamp_to[1], clamp_to[2])
    end
    return preds
end

"""
    crossfit_outcome_predictions(df, outcome, treatment, covariates, folds, rng; learners) -> Vector{Float64}
"""
function crossfit_outcome_predictions(
    df::DataFrame,
    outcome::Symbol,
    treatment::Symbol,
    covariates::Vector{Symbol},
    folds::Int,
    rng;
    learners = DEFAULT_SL_LEARNERS,
)
    return _crossfit_super_learner(
        df, Float64.(df[!, outcome]), covariates, folds, rng;
        treatment = treatment, learners = learners,
    )
end

"""
    crossfit_predict_outcome(df, outcome, treatment, covariates, treatment_values, folds, rng; learners) -> Vector{Float64}
"""
function crossfit_predict_outcome(
    df::DataFrame,
    outcome::Symbol,
    treatment::Symbol,
    covariates::Vector{Symbol},
    treatment_values::AbstractVector{<:Real},
    folds::Int,
    rng;
    learners = DEFAULT_SL_LEARNERS,
)
    return _crossfit_super_learner(
        df, Float64.(df[!, outcome]), covariates, folds, rng;
        treatment = treatment, treatment_values = Float64.(treatment_values),
        learners = learners,
    )
end

"""
    crossfit_treatment_mean(df, treatment, covariates, folds, rng; learners) -> Vector{Float64}
"""
function crossfit_treatment_mean(
    df::DataFrame,
    treatment::Symbol,
    covariates::Vector{Symbol},
    folds::Int,
    rng;
    learners = DEFAULT_SL_LEARNERS,
)
    return _crossfit_super_learner(
        df, Float64.(df[!, treatment]), covariates, folds, rng; learners = learners,
    )
end

"""
    crossfit_propensity(df, treatment, covariates, folds, rng; learners, fold_sets) -> Vector{Float64}

Cross-fitted propensity scores, combined with inverse-MSE weights and clamped to
`[1e-3, 1 - 1e-3]`. Pass `fold_sets` to share a partition with other nuisances
fitted in the same estimator.
"""
function crossfit_propensity(
    df::DataFrame,
    treatment::Symbol,
    covariates::Vector{Symbol},
    folds::Int,
    rng;
    learners = (:logistic, :mean),
    fold_sets = nothing,
)
    return _crossfit_super_learner(
        df, Float64.(df[!, treatment]), covariates, folds, rng;
        learners = learners, family = :binomial,
        metalearner = :invmse, clamp_to = (1e-3, 1 - 1e-3),
        fold_sets = fold_sets,
    )
end

"""
    columns_present(df, cols) -> Vector{Symbol}
"""
function columns_present(df::DataFrame, cols)
    return [column for column in cols if hasproperty(df, column)]
end

export DEFAULT_SL_LEARNERS, RICH_SL_LEARNERS
export validate_contrast_learners
export SuperLearnerFit
export design_matrix, covariate_design_matrix, outcome_design_matrix, sparse_exposure_diagnostic
export fit_super_learner, predict_super_learner
export crossfit_outcome_predictions, crossfit_predict_outcome
export crossfit_treatment_mean, crossfit_propensity, columns_present
